# Trendify
An e-commerce shopping website designed to help users find the best clothes based on their preferences.
